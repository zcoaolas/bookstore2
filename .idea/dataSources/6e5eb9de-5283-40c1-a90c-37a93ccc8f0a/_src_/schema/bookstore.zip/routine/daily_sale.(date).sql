CREATE FUNCTION daily_sale(d DATE)
  RETURNS DECIMAL(10, 2)
  BEGIN
declare x decimal(10,2);
select sum(amount*bookPrice) into x
from `order` join books on books.id=`order`.bookId
where `order`.time=d;
return x;
end;
