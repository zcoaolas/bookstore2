CREATE FUNCTION hotbook(bid INT)
  RETURNS INT
  begin
declare x int(11);
select max(Tmp.s) into x from
(select sum(amount) as s from `order`GROUP BY bookId) as Tmp;
return x;
end;
