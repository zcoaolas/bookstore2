CREATE FUNCTION booksale(bid INT)
  RETURNS INT
  begin
declare x int(11);
select sum(amount) into x
from `order`
GROUP BY bookId;
return x;
end;
